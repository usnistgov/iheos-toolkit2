package org.apache.axis2.jaxws.samples.client;
     


import org.apache.axiom.soap.SOAPBody;
import org.apache.axis2.client.async.AxisCallback;
import org.apache.axis2.context.MessageContext;

import javax.servlet.http.HttpServletRequest;
     
     
    public class MyAsyncClientCallback implements AxisCallback { 
        public void onMessage(MessageContext messageContext) { 
            if (messageContext!=null) {
            
            HttpServletRequest obj =(HttpServletRequest)messageContext.getProperty("transport.http.servletRequest");
            
            if (obj!=null) {
            
                System.out.println("Acceptable Encoding type: "+obj.getHeader("Accept-Encoding"));
                System.out.println("Acceptable character set: " +obj.getHeader("Accept-Charset"));
                System.out.println("Acceptable Media Type: "+obj.getHeader("Accept"));

            } else 
                       
                System.out.println("Obj is null " );
            }
            
        
           SOAPBody msg = messageContext.getEnvelope().getBody(); 
           System.out.println(msg); 
       } 
    
       public void onFault(MessageContext messageContext) { 
           messageContext.getFailureReason().printStackTrace(); 
       } 
    
       public void onError(Exception e) { 
           System.err.println(e.getMessage()); 
       } 
    
       public void onComplete() { 
           System.out.println("Invocation is complete"); 
           //In real application you do not need to terminate the program
           // If running in a web server do not call this but enable this when running in a standalone type program
          // System.exit(0);
       } 
   } 
