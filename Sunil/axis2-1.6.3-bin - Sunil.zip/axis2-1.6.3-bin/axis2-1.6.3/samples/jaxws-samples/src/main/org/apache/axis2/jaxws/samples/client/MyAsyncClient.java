package org.apache.axis2.jaxws.samples.client;
     
import org.apache.axiom.om.OMAbstractFactory; 
import org.apache.axiom.om.OMElement; 
import org.apache.axiom.om.OMFactory; 
import org.apache.axiom.om.OMNamespace; 

import org.apache.axis2.context.ConfigurationContext; 
    import org.apache.axis2.context.ConfigurationContextFactory; 
    import org.apache.axis2.context.MessageContextConstants;
import org.apache.axis2.addressing.EndpointReference; 
import org.apache.axis2.client.Options; 
import org.apache.axis2.client.ServiceClient; 
import org.apache.axis2.Constants;

public class MyAsyncClient {

    public static void main(String[] args) throws Exception { 
    try {
           ServiceClient client = new ServiceClient(); 
            Options opts = new Options(); 
           
           opts.setTo(new EndpointReference("http://localhost:8080/axis2/services/EchoService")); 
           opts.setProperty(MessageContextConstants.TRANSPORT_URL,"http://localhost:8080/axis2/services/EchoService");
           
           opts.setAction("urn:echo"); 
           client.engageModule("addressing");  // async 
           
           
           
           
           opts.setTransportInProtocol(Constants.TRANSPORT_HTTP);
           
           String axis2xml=System.getProperty("org.apache.axis2.jaxws.config.path");
           
              ConfigurationContext configurationContext = 
               ConfigurationContextFactory.createConfigurationContextFromFileSystem(axis2xml); 
               
           opts.setSenderTransport(Constants.TRANSPORT_HTTP,configurationContext.getAxisConfiguration());
           
           opts.setUseSeparateListener(true);  // async 
           
           
           client.setOptions(opts); 
           client.sendReceiveNonBlocking(createPayLoad(), new MyAsyncClientCallback()); 
           System.out.println("send the message"); 
           while (true) { 
               Thread.sleep(100); 
           } 
           
       } catch (Throwable t) {
        t.printStackTrace();
       }
       } 
    
       public static OMElement createPayLoad() { 
           OMFactory fac = OMAbstractFactory.getOMFactory(); 
           OMNamespace omNs = fac.createOMNamespace( 
                   "http://echo2.samples.jaxws.axis2.apache.org", "ns"); 
           OMElement method = fac.createOMElement("echo", omNs); 
           OMElement value = fac.createOMElement("value", omNs); 
           method.addChild(value); 
           value.setText("Axis2"); 
           return method; 
    
       } 
   

}