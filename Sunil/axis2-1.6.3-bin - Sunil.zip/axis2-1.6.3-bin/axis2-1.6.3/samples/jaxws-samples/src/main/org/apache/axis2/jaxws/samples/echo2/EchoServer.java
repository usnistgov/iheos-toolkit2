package org.apache.axis2.jaxws.samples.echo2;
     
import org.apache.axis2.engine.AxisServer; 
     
     
    public class EchoServer { 
        public static void main(String[] args) throws Exception { 
            new AxisServer().deployService(EchoService.class.getName()); 
        } 
   } 
   