package org.apache.axis2.jaxws.samples.client;

public class MyAsyncOperationClient {



    public static void main(String[] args) throws Exception {

        MyAsyncOperation myAsyncOperation = new MyAsyncOperation();

        myAsyncOperation.run();
    }

}