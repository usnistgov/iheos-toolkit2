package org.apache.axis2.jaxws.samples.client;


import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.soap.SOAPBody;
import org.apache.axiom.soap.SOAPEnvelope;
import org.apache.axiom.soap.SOAPFactory;
import org.apache.axis2.AxisFault;
import org.apache.axis2.Constants;
import org.apache.axis2.addressing.AddressingConstants;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.OperationClient;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.client.async.AxisCallback;
import org.apache.axis2.context.ConfigurationContext;
import org.apache.axis2.context.ConfigurationContextFactory;
import org.apache.axis2.context.MessageContext;
import org.apache.axis2.context.MessageContextConstants;

import javax.servlet.http.HttpServletRequest;


/**
 * Created by skb1 on 12/3/2015.
 */
public class MyAsyncOperation {

    ServiceClient client = null;
    OperationClient operationClient = null;
    boolean done = false;

    public void run() {
        try {

            client = new ServiceClient();
//            Options opts = new Options();

            client.engageModule("addressing");  // async

            operationClient = client
                    .createClient(ServiceClient.ANON_ROBUST_OUT_ONLY_OP); // Use ? ServiceClient.ANON_OUT_IN_OP

            MessageContext outMsgCtx = new MessageContext();

            Options opts = outMsgCtx.getOptions();


            opts.setTo(new EndpointReference("http://localhost:8080/axis2/services/EchoService"));
            opts.setProperty(MessageContextConstants.TRANSPORT_URL, "http://localhost:8080/axis2/services/EchoService");

            opts.setAction("urn:echo");

            opts.setTransportInProtocol(Constants.TRANSPORT_HTTP);

            String axis2xml = System.getProperty("org.apache.axis2.jaxws.config.path");

            ConfigurationContext configurationContext =
                    ConfigurationContextFactory.createConfigurationContextFromFileSystem(axis2xml);

            opts.setSenderTransport(Constants.TRANSPORT_HTTP, configurationContext.getAxisConfiguration());

            opts.setUseSeparateListener(true);  // async

            opts.setProperty(
                    AddressingConstants.ADD_MUST_UNDERSTAND_TO_ADDRESSING_HEADERS,
                    Boolean.TRUE);

            opts.setCallTransportCleanup(true);

            SOAPEnvelope envelope = createSOAPEnvelope();

            outMsgCtx.setEnvelope(envelope);

            operationClient.addMessageContext(outMsgCtx);


            AxisCallback myCallback = new AxisCallback() {

                public void onComplete() {
                    done = true;
                    System.out.println("Done.");
                }

                public void onMessage(MessageContext messageContext) {
                    if (messageContext!=null) {

                        HttpServletRequest obj =(HttpServletRequest)messageContext.getProperty("transport.http.servletRequest");

                        if (obj!=null) {

                            System.out.println("Acceptable Encoding type: "+obj.getHeader("Accept-Encoding"));
                            System.out.println("Acceptable character set: " +obj.getHeader("Accept-Charset"));
                            System.out.println("Acceptable Media Type: "+obj.getHeader("Accept"));

                        } else

                            System.out.println("Obj is null " );
                    }


                    SOAPBody msg = messageContext.getEnvelope().getBody();
                    System.out.println(msg);
                }

                public void onFault(MessageContext messageContext) {
                    messageContext.getFailureReason().printStackTrace();
                }

                public void onError(Exception e) {
                    System.err.println(e.getMessage());
                }

            };



            operationClient.setCallback(myCallback); // new MyAsyncClientCallback()

            // client.setOptions(opts);
            // client.sendReceiveNonBlocking(createPayLoad(), new MyAsyncClientCallback());

            System.out.println("send the message");

            operationClient.execute(false); // execute true=sync or false=async


            // If running in a web server do not call this but enable this when running in a standalone type program
            System.out.println("waiting...");
            while (!done) {
                System.out.print(".");
                Thread.sleep(500);
            }

            System.out.println("Cleaning up...");
            // should be taken care of by the callTransportCleanup
            client.cleanupTransport();
            client.cleanup();



        } catch (Throwable t) {
            t.printStackTrace();
        }
    }



    public static OMElement createPayLoad() {
        OMFactory fac = OMAbstractFactory.getOMFactory();
        OMNamespace omNs = fac.createOMNamespace(
                "http://echo2.samples.jaxws.axis2.apache.org", "ns");
        OMElement method = fac.createOMElement("echo", omNs);
        OMElement value = fac.createOMElement("value", omNs);
        method.addChild(value);
        value.setText("Axis2");
        return method;

    }

    public static SOAPEnvelope createSOAPEnvelope()  {
        SOAPFactory fac;

        boolean soap12 = true;

        if (soap12)
            fac = OMAbstractFactory.getSOAP12Factory();
        else
            fac = OMAbstractFactory.getSOAP11Factory();

        SOAPEnvelope envelope = fac.getDefaultEnvelope();


        envelope.getBody().addChild(createPayLoad());

        return envelope;

    }

    MessageContext getInputMessageContext() throws Exception,
            AxisFault {
        if (operationClient == null) {
            Object in = client.getServiceContext()
                    .getLastOperationContext().getMessageContexts().get("In");
            if (!(in instanceof MessageContext))
                throw new Exception(
                        "Soap: In MessageContext of type "
                                + in.getClass().getName()
                                + " instead of MessageContext");
            MessageContext inMsgCxt = (MessageContext) in;
            return inMsgCxt;
        }
        return operationClient.getMessageContext("In");

    }
}
