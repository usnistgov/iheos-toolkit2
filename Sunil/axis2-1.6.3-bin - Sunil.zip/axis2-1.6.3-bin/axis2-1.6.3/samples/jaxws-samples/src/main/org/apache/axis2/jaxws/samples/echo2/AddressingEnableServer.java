package org.apache.axis2.jaxws.samples.echo2;
     
    import org.apache.axis2.engine.AxisServer; 
    import org.apache.axis2.context.ConfigurationContext; 
    import org.apache.axis2.context.ConfigurationContextFactory; 
    import org.apache.axis2.transport.http.SimpleHTTPServer; 
    import org.apache.axis2.description.AxisService; 
    import org.apache.axis2.description.Parameter; 
    import org.apache.axis2.description.java2wsdl.Java2WSDLConstants; 
    
   public class AddressingEnableServer { 
       public static void main(String[] args) throws Exception{ 

       String axis2xml=System.getProperty("org.apache.axis2.jaxws.config.path");
           
           
       
          ConfigurationContext configurationContext = 
               ConfigurationContextFactory.createConfigurationContextFromFileSystem(axis2xml); 
       
           AxisService service1 = 
               AxisService.createService(EchoService.class.getName(), 
               configurationContext.getAxisConfiguration()); 
           configurationContext.getAxisConfiguration().engageModule("addressing"); 
           configurationContext.getAxisConfiguration().addService(service1); 
 
 
           SimpleHTTPServer smt = new SimpleHTTPServer(configurationContext, 8080); 
           smt.start(); 
       } 
   } 