package org.apache.axis2.jaxws.samples.echo2;
 
     
     
    public class EchoService { 
     
        public String echo(String value){ 
            return "from server>> " + value; 
        } 
    } 