Sample for Yahoo - Search - REST
=================================

Introduction
============

Axis2 client API has facilities to invoke REST interfaces. The API to be used is almost the same
as the one we use while invoking with REST.

Yahoo provides a REST API to call its search service. This sample demonstrates how to call Yahoo
search service using an Axis2 client.

Pre-Requisites
==============

Apache Ant 1.6.2 or later

Running The Sample
==================

Type "ant" from Axis2_HOME/samples/yahoorestsearch directory.

Help
====
Please contact axis-user list (axis-user@ws.apache.org) if you have any trouble running the sample.
